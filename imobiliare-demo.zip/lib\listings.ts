export interface Listing {
  id: string;
  title: string;
  location: string;
  city: "Tiranë" | "Durrës" | "Vlorë" | "Sarandë";
  price: string;
  priceValue: number;
  area: string;
  bedrooms: number;
  type: "Shitje" | "Qira";
  floor: number;
  description: string;
  features: string[];
  image: string;
  isMonthly?: boolean;
}

export const listings: Listing[] = [
  {
    id: "1",
    title: "Apartament 2+1",
    location: "Bllok, Tiranë",
    city: "Tiranë",
    price: "120,000€",
    priceValue: 120000,
    area: "85m²",
    bedrooms: 2,
    type: "Shitje",
    floor: 5,
    description:
      "Apartament modern 2+1 në zemër të Bllokut, me pamje mahnitëse nga qyteti. I mobiluar plotësisht me mobilje cilësore, me ngrohje qendrore dhe parking nëntokësor. Ndodhet në lagjen më prestigjioze të Tiranës, pranë restoranteve, kafeve dhe qendrave tregtare.",
    features: [
      "2 dhoma gjumi",
      "Kati 5",
      "Pamje nga qyteti",
      "I mobiluar plotësisht",
      "Ngrohje qendrore",
      "Parking nëntokësor",
      "85m² sipërfaqe",
      "Ballkon i madh",
    ],
    image:
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=80&fit=crop",
  },
  {
    id: "2",
    title: "Apartament 3+1",
    location: "Plazh, Durrës",
    city: "Durrës",
    price: "95,000€",
    priceValue: 95000,
    area: "110m²",
    bedrooms: 3,
    type: "Shitje",
    floor: 3,
    description:
      "Apartament i mrekullueshëm 3+1, vetëm 50 metra nga deti i Durrësit. Me terrasa të hapura, pamje direkte nga deti dhe parking të lirë. Ideal si shtëpi pushimi ose investim, me infrastrukturë të plotë dhe afërsisht 10 minuta nga qendra e qytetit.",
    features: [
      "3 dhoma gjumi",
      "50m nga deti",
      "Parking i lirë",
      "Terrasa e hapur",
      "Kati 3",
      "Pamje nga deti",
      "110m² sipërfaqe",
      "Afër qendrës",
    ],
    image:
      "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800&q=80&fit=crop",
  },
  {
    id: "3",
    title: "Vilë Luksoze",
    location: "Sarandë",
    city: "Sarandë",
    price: "280,000€",
    priceValue: 280000,
    area: "250m²",
    bedrooms: 5,
    type: "Shitje",
    floor: 1,
    description:
      "Vilë e jashtëzakonshme luksoze në Sarandë, me pishinë private dhe kopsht të mrekullueshëm privat. Pamje panoramike nga deti Jon dhe ishujt grek. Me 5 dhoma gjumi, 4 banjo, garazh të dyfishtë dhe sistemim i plotë i çiftit. Ky është investimi i jetës.",
    features: [
      "5 dhoma gjumi",
      "Pishinë private",
      "Kopsht privat",
      "Pamje nga deti",
      "Garazh i dyfishtë",
      "4 banjo",
      "250m² sipërfaqe",
      "Sistemim i plotë",
    ],
    image:
      "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800&q=80&fit=crop",
  },
  {
    id: "4",
    title: "Apartament 1+1",
    location: "Unaza e Re, Tiranë",
    city: "Tiranë",
    price: "75,000€",
    priceValue: 75000,
    area: "55m²",
    bedrooms: 1,
    type: "Shitje",
    floor: 3,
    description:
      "Apartament i ri modern 1+1 me ndriçim natyral të shkëlqyer dhe cilësi ndërtimi të lartë. Afër qendrës dhe transportit publik, ideal për çifte të reja ose si investim. Ndërtim 2023, me materiale premium dhe finishe moderne.",
    features: [
      "1 dhomë gjumi",
      "I ri (2023)",
      "Kati 3",
      "Ndriçim natyral",
      "Afër qendrës",
      "Transport publik",
      "55m² sipërfaqe",
      "Finishe premium",
    ],
    image:
      "https://images.unsplash.com/photo-1555636222-cae831e670b3?w=800&q=80&fit=crop",
  },
  {
    id: "5",
    title: "Zyrë për Qira",
    location: "Qendër, Tiranë",
    city: "Tiranë",
    price: "800€/muaj",
    priceValue: 800,
    area: "60m²",
    bedrooms: 0,
    type: "Qira",
    floor: 2,
    description:
      "Zyrë moderne dhe fully equipped në zemër të Tiranës, afër Bulevardit kryesor. Ideale për biznese dhe kompani të vogla e të mesme. Me internet fiber optik, kondicionim, salla takimesh dhe parking. Disponueshme menjëherë.",
    features: [
      "60m² sipërfaqe",
      "Kati 2",
      "Fully equipped",
      "Afër Bulevardit",
      "Internet fiber",
      "Kondicionim",
      "Sallë takimesh",
      "Parking",
    ],
    image:
      "https://images.unsplash.com/photo-1497366216548-37526070297c?w=800&q=80&fit=crop",
    isMonthly: true,
  },
  {
    id: "6",
    title: "Apartament 2+1",
    location: "Lungomare, Vlorë",
    city: "Vlorë",
    price: "110,000€",
    priceValue: 110000,
    area: "90m²",
    bedrooms: 2,
    type: "Shitje",
    floor: 4,
    description:
      "Apartament 2+1 me pamje mahnitëse nga deti i Vlorës, direkt në lungomare. I mobiluar plotësisht me mobilje luksoze dhe gati për banim menjëherë. Ballkon i madh me pamje 180° nga deti Adriatik. Vendndodhja ideale në zemër të lungomareve.",
    features: [
      "2 dhoma gjumi",
      "Pamje nga deti",
      "I mobiluar plotësisht",
      "Kati 4",
      "Lungomare",
      "Ballkon i madh",
      "90m² sipërfaqe",
      "Gati për banim",
    ],
    image:
      "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800&q=80&fit=crop",
  },
];

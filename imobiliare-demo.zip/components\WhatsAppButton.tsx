"use client";

import { motion } from "framer-motion";
import { FaWhatsapp } from "react-icons/fa";

export default function WhatsAppButton() {
  return (
    <motion.a
      href="https://wa.me/355692081322"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 flex items-center gap-0 group"
      initial={{ opacity: 0, scale: 0.8, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 1.2 }}
      aria-label="Na kontaktoni në WhatsApp"
    >
      {/* Tooltip label */}
      <span className="overflow-hidden max-w-0 group-hover:max-w-[180px] transition-all duration-500 ease-out whitespace-nowrap bg-[#c9a84c] text-black text-xs font-semibold px-3 py-2 rounded-l-full">
        Na kontaktoni tani
      </span>

      {/* Button */}
      <motion.div
        className="w-14 h-14 bg-[#c9a84c] rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(201,168,76,0.4)] hover:shadow-[0_0_30px_rgba(201,168,76,0.6)] transition-shadow duration-300"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
      >
        <FaWhatsapp size={26} className="text-black" />
      </motion.div>
    </motion.a>
  );
}

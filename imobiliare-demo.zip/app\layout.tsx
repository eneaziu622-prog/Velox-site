import type { Metadata } from "next";
import { Inter, Playfair_Display } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";
import VeloxBadge from "@/components/VeloxBadge";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-playfair",
  display: "swap",
  weight: ["400", "600", "700", "800"],
});

export const metadata: Metadata = {
  title: "Imobiliare Demo | Prona të Zgjedhura në Shqipëri",
  description:
    "Shërbim profesional imobiliar në të gjithë Shqipërinë. Gjeni apartamentin, vilën ose zyrën tuaj të ëndrrave me Imobiliare Demo.",
  keywords:
    "imobiliare, prona, apartamente, shqiperi, tirane, vlore, durres, sarande, shitje, qira",
  openGraph: {
    title: "Imobiliare Demo | Prona të Zgjedhura në Shqipëri",
    description:
      "Shërbim profesional imobiliar në të gjithë Shqipërinë. Gjeni pronën tuaj të ëndrrave.",
    type: "website",
    locale: "sq_AL",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="sq" className={`${inter.variable} ${playfair.variable}`}>
      <body className="bg-surface text-white antialiased min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-1">{children}</main>
        <Footer />
        <WhatsAppButton />
        <VeloxBadge />
      </body>
    </html>
  );
}

import Link from "next/link";

export default function VeloxBadge() {
  return (
    <Link
      href="https://velox-design.netlify.app"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 left-6 z-50 flex items-center gap-2 bg-[#111111] border border-[#2a2a2a] text-[#c9a84c] text-xs font-semibold px-3.5 py-2 rounded-full hover:bg-[#c9a84c] hover:text-black hover:border-[#c9a84c] transition-all duration-300 shadow-lg group"
      aria-label="Built by VELOX Studio"
    >
      <span className="w-5 h-5 bg-[#c9a84c] group-hover:bg-black text-black group-hover:text-[#c9a84c] rounded-full flex items-center justify-center font-display font-bold text-[10px] transition-colors duration-300">
        V
      </span>
      <span>Built by VELOX</span>
    </Link>
  );
}

"use client";

import { motion } from "framer-motion";
import { HiLightningBolt, HiBadgeCheck, HiShieldCheck } from "react-icons/hi";

const features = [
  {
    icon: HiLightningBolt,
    title: "Shpejtësi",
    description:
      "Gjejmë pronën tuaj ideale brenda 48 orëve. Procesi i shitje-blerjes kompletë brenda 30 ditëve.",
    stat: "48h",
    statLabel: "kohë mesatare",
  },
  {
    icon: HiBadgeCheck,
    title: "Profesionalizëm",
    description:
      "Agjentë me 10+ vjet eksperiencë në tregun imobiliar shqiptar. Konsulencë ligjore falas.",
    stat: "10+",
    statLabel: "vite eksperiencë",
  },
  {
    icon: HiShieldCheck,
    title: "Besueshmëri",
    description:
      "Transparencë totale në çdo hap të procesit. Mbi 500 klientë të kënaqur dhe transaksione të sigurta.",
    stat: "500+",
    statLabel: "klientë të kënaqur",
  },
];

export default function WhyChooseUs() {
  return (
    <section className="py-24 bg-[#060606] relative overflow-hidden">
      {/* Gold accent glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#c9a84c]/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        {/* Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="h-px w-10 bg-[#c9a84c]" />
            <span className="text-[#c9a84c] text-xs tracking-[0.35em] uppercase font-medium">
              Pse ne
            </span>
            <div className="h-px w-10 bg-[#c9a84c]" />
          </div>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-4">
            Pse na Zgjidhni Ne?
          </h2>
          <p className="text-gray-400 max-w-xl mx-auto text-sm sm:text-base">
            Me ne, blerja ose shitja e pronës bëhet e thjeshtë, e sigurt dhe e
            shpejtë.
          </p>
        </motion.div>

        {/* Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
          {features.map(({ icon: Icon, title, description, stat, statLabel }, i) => (
            <motion.div
              key={title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.15 }}
              className="group relative bg-[#111111] border border-[#1a1a1a] hover:border-[#c9a84c]/30 rounded-2xl p-8 transition-all duration-500 overflow-hidden"
            >
              {/* Hover glow */}
              <div className="absolute inset-0 bg-gradient-to-br from-[#c9a84c]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

              {/* Icon */}
              <div className="relative mb-6">
                <div className="w-14 h-14 bg-[#1a1a1a] border border-[#2a2a2a] group-hover:border-[#c9a84c]/50 rounded-xl flex items-center justify-center transition-colors duration-300">
                  <Icon className="text-[#c9a84c]" size={26} />
                </div>
              </div>

              {/* Content */}
              <h3 className="font-display text-xl font-bold text-white mb-3">
                {title}
              </h3>
              <p className="text-gray-400 text-sm leading-relaxed mb-6">
                {description}
              </p>

              {/* Stat */}
              <div className="border-t border-[#1a1a1a] pt-5 flex items-end gap-2">
                <span className="font-display text-3xl font-bold text-[#c9a84c]">
                  {stat}
                </span>
                <span className="text-xs text-gray-500 mb-1">{statLabel}</span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

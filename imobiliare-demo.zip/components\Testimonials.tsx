"use client";

import { motion } from "framer-motion";
import { HiStar } from "react-icons/hi";
import { FaQuoteLeft } from "react-icons/fa";

const testimonials = [
  {
    name: "Arta Berberi",
    role: "Bleresse apartamenti, Tiranë",
    avatar: "AB",
    text: "Shërbim i shkëlqyer dhe tepër profesional! Gjeta apartamentin e ëndrrave tim brenda 2 javësh. Agjenti ishte gjithmonë i disponueshëm dhe i ndershëm. Rekomandoj pa asnjë hezitim!",
    rating: 5,
  },
  {
    name: "Genti Maloku",
    role: "Investitor, Durrës",
    avatar: "GM",
    text: "Kam punuar me shumë agjenci, por kjo është e pari që ka dhënë rezultate të shpejta dhe të besueshme. Procesi ishte transparent dhe çmimi i drejtë. Faleminderit shumë ekipit!",
    rating: 5,
  },
  {
    name: "Mirela Çela",
    role: "Shitëse vilë, Sarandë",
    avatar: "MC",
    text: "Vilën time e shita në dy muaj, çmim shumë të mirë. Ekipi e trajtoi çdo detaj me kujdes dhe profesionalizëm. Ndjeja sikur po punonin për interesin tim, jo vetëm për komisionin.",
    rating: 5,
  },
];

export default function Testimonials() {
  return (
    <section className="py-24 bg-[#0a0a0a]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          className="text-center mb-14"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="h-px w-10 bg-[#c9a84c]" />
            <span className="text-[#c9a84c] text-xs tracking-[0.35em] uppercase font-medium">
              Çfarë thonë klientët
            </span>
            <div className="h-px w-10 bg-[#c9a84c]" />
          </div>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-4">
            Vlerësimet e Klientëve
          </h2>
          <p className="text-gray-400 max-w-lg mx-auto text-sm sm:text-base">
            Dëgjoni çfarë thonë klientët tanë të kënaqur për
            shërbimin tonë.
          </p>
        </motion.div>

        {/* Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map(({ name, role, avatar, text, rating }, i) => (
            <motion.div
              key={name}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.15 }}
              className="bg-[#111111] border border-[#1a1a1a] hover:border-[#c9a84c]/30 rounded-2xl p-7 transition-all duration-500 flex flex-col relative overflow-hidden group"
            >
              {/* Quote icon */}
              <FaQuoteLeft
                className="absolute top-6 right-6 text-[#c9a84c]/10 group-hover:text-[#c9a84c]/20 transition-colors duration-300"
                size={36}
              />

              {/* Stars */}
              <div className="flex gap-1 mb-5">
                {Array.from({ length: rating }).map((_, idx) => (
                  <HiStar key={idx} className="text-[#c9a84c]" size={16} />
                ))}
              </div>

              {/* Text */}
              <p className="text-gray-300 text-sm leading-relaxed flex-1 mb-6 italic">
                &ldquo;{text}&rdquo;
              </p>

              {/* Author */}
              <div className="flex items-center gap-3 border-t border-[#1a1a1a] pt-5">
                <div className="w-10 h-10 rounded-full bg-[#c9a84c] flex items-center justify-center font-display font-bold text-black text-sm shrink-0">
                  {avatar}
                </div>
                <div>
                  <div className="text-white text-sm font-semibold">{name}</div>
                  <div className="text-gray-500 text-xs">{role}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

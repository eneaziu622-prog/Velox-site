"use client";

import { HiSearch } from "react-icons/hi";

const cities = ["Të gjitha", "Tiranë", "Durrës", "Vlorë", "Sarandë"];
const types = ["Të gjitha", "Shitje", "Qira"];

interface SearchFilterProps {
  search: string;
  city: string;
  type: string;
  onSearch: (v: string) => void;
  onCity: (v: string) => void;
  onType: (v: string) => void;
  resultCount: number;
}

export default function SearchFilter({
  search,
  city,
  type,
  onSearch,
  onCity,
  onType,
  resultCount,
}: SearchFilterProps) {
  return (
    <div className="bg-[#111111] border border-[#1a1a1a] rounded-2xl p-5 md:p-6 mb-10">
      {/* Search */}
      <div className="relative mb-4">
        <HiSearch
          className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500"
          size={18}
        />
        <input
          type="text"
          placeholder="Kërko sipas titullit ose vendndodhjes..."
          value={search}
          onChange={(e) => onSearch(e.target.value)}
          className="w-full bg-[#0a0a0a] border border-[#2a2a2a] focus:border-[#c9a84c] rounded-xl pl-11 pr-4 py-3 text-white placeholder-gray-600 text-sm outline-none transition-colors duration-200"
        />
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
        {/* City filter */}
        <div className="flex-1">
          <p className="text-xs text-gray-500 uppercase tracking-widest mb-2 font-medium">
            Qyteti
          </p>
          <div className="flex flex-wrap gap-2">
            {cities.map((c) => (
              <button
                key={c}
                onClick={() => onCity(c)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all duration-200 ${
                  city === c
                    ? "bg-[#c9a84c] text-black"
                    : "bg-[#0a0a0a] border border-[#2a2a2a] text-gray-400 hover:border-[#c9a84c]/50 hover:text-[#c9a84c]"
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        {/* Type filter */}
        <div>
          <p className="text-xs text-gray-500 uppercase tracking-widest mb-2 font-medium">
            Lloji
          </p>
          <div className="flex gap-2">
            {types.map((t) => (
              <button
                key={t}
                onClick={() => onType(t)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all duration-200 ${
                  type === t
                    ? "bg-[#c9a84c] text-black"
                    : "bg-[#0a0a0a] border border-[#2a2a2a] text-gray-400 hover:border-[#c9a84c]/50 hover:text-[#c9a84c]"
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Result count */}
      <div className="mt-4 pt-4 border-t border-[#1a1a1a] text-xs text-gray-500">
        <span className="text-[#c9a84c] font-semibold">{resultCount}</span>{" "}
        prona të gjetura
      </div>
    </div>
  );
}

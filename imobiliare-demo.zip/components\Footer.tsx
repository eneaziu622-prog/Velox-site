import Link from "next/link";
import { FaInstagram, FaFacebookF, FaLinkedinIn, FaWhatsapp } from "react-icons/fa";
import { HiLocationMarker, HiPhone, HiMail } from "react-icons/hi";

const socialLinks = [
  { icon: FaInstagram, href: "#", label: "Instagram" },
  { icon: FaFacebookF, href: "#", label: "Facebook" },
  { icon: FaLinkedinIn, href: "#", label: "LinkedIn" },
];

export default function Footer() {
  return (
    <footer id="kontakt" className="bg-[#080808] border-t border-[#1a1a1a]">
      {/* Main footer content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="mb-5">
              <span className="font-display text-2xl font-bold tracking-widest text-[#c9a84c]">
                IMOBILIARE
              </span>
              <span className="block text-[10px] tracking-[0.4em] text-gray-500 uppercase mt-0.5">
                Demo
              </span>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed max-w-xs mb-6">
              Shërbim profesional imobiliar në të gjithë Shqipërinë. Gjejmë
              pronën e ëndrrave tuaja me eksperiencën dhe dedikimin tonë.
            </p>
            <div className="flex gap-3">
              {socialLinks.map(({ icon: Icon, href, label }) => (
                <a
                  key={label}
                  href={href}
                  aria-label={label}
                  className="w-9 h-9 rounded-full border border-[#2a2a2a] flex items-center justify-center text-gray-400 hover:border-[#c9a84c] hover:text-[#c9a84c] transition-all duration-300"
                >
                  <Icon size={15} />
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          <div>
            <h3 className="text-white font-semibold text-sm tracking-widest uppercase mb-5">
              Navigim
            </h3>
            <ul className="space-y-3">
              {[
                { label: "Kryefaqja", href: "/" },
                { label: "Të gjitha pronat", href: "/prona" },
                { label: "Prona për shitje", href: "/prona?type=Shitje" },
                { label: "Prona për qira", href: "/prona?type=Qira" },
              ].map(({ label, href }) => (
                <li key={label}>
                  <Link
                    href={href}
                    className="text-gray-400 hover:text-[#c9a84c] text-sm transition-colors duration-200"
                  >
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-white font-semibold text-sm tracking-widest uppercase mb-5">
              Kontakt
            </h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3 text-sm text-gray-400">
                <HiLocationMarker className="text-[#c9a84c] mt-0.5 shrink-0" size={16} />
                <span>Rruga Myslym Shyri, Tiranë</span>
              </li>
              <li>
                <a
                  href="tel:+355692081322"
                  className="flex items-center gap-3 text-sm text-gray-400 hover:text-[#c9a84c] transition-colors"
                >
                  <HiPhone className="text-[#c9a84c] shrink-0" size={16} />
                  +355 69 208 1322
                </a>
              </li>
              <li>
                <a
                  href="mailto:info@velox-design.netlify.app"
                  className="flex items-center gap-3 text-sm text-gray-400 hover:text-[#c9a84c] transition-colors"
                >
                  <HiMail className="text-[#c9a84c] shrink-0" size={16} />
                  info@velox-design.netlify.app
                </a>
              </li>
              <li>
                <a
                  href="https://wa.me/355692081322"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 mt-1 text-sm font-medium px-4 py-2 bg-[#c9a84c] text-black rounded-full hover:bg-[#d4b86a] transition-colors"
                >
                  <FaWhatsapp size={14} />
                  Na kontaktoni
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-[#1a1a1a] py-5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-gray-600">
          <span>© 2024 Imobiliare Demo. Të gjitha të drejtat e rezervuara.</span>
          <a
            href="https://velox-design.netlify.app"
            target="_blank"
            rel="noopener noreferrer"
            className="text-[#c9a84c] hover:text-[#d4b86a] transition-colors"
          >
            Faqe e ndërtuar nga VELOX Studio — velox-design.netlify.app
          </a>
        </div>
      </div>
    </footer>
  );
}

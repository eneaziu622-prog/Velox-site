"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { HiArrowRight } from "react-icons/hi";
import PropertyCard from "@/components/PropertyCard";
import { listings } from "@/lib/listings";

export default function FeaturedListings() {
  return (
    <section className="py-24 bg-[#0a0a0a]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          className="text-center mb-14"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="h-px w-10 bg-[#c9a84c]" />
            <span className="text-[#c9a84c] text-xs tracking-[0.35em] uppercase font-medium">
              Prona të zgjedhura
            </span>
            <div className="h-px w-10 bg-[#c9a84c]" />
          </div>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-4">
            Pronat e Disponueshme
          </h2>
          <p className="text-gray-400 max-w-xl mx-auto text-sm sm:text-base leading-relaxed">
            Zgjidhni nga koleksioni ynë i pronave luksoze dhe moderne në
            destinacionet më të kërkuara të Shqipërisë.
          </p>
        </motion.div>

        {/* Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {listings.map((listing, i) => (
            <PropertyCard key={listing.id} listing={listing} index={i} />
          ))}
        </div>

        {/* CTA */}
        <motion.div
          className="text-center mt-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <Link
            href="/prona"
            className="inline-flex items-center gap-2 border border-[#c9a84c]/40 text-[#c9a84c] font-semibold px-8 py-3.5 rounded-full hover:bg-[#c9a84c] hover:text-black hover:border-[#c9a84c] transition-all duration-300 text-sm tracking-wider"
          >
            Shiko të gjitha pronat
            <HiArrowRight size={16} />
          </Link>
        </motion.div>
      </div>
    </section>
  );
}

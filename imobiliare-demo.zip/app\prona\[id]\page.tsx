import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { listings } from "@/lib/listings";
import { FaWhatsapp } from "react-icons/fa";
import { HiLocationMarker, HiArrowLeft, HiCheckCircle } from "react-icons/hi";
import { IoBed } from "react-icons/io5";
import { MdSquareFoot } from "react-icons/md";
import { HiHomeModern } from "react-icons/hi2";

type Params = Promise<{ id: string }>;

export async function generateStaticParams() {
  return listings.map((l) => ({ id: l.id }));
}

export async function generateMetadata({
  params,
}: {
  params: Params;
}): Promise<Metadata> {
  const { id } = await params;
  const listing = listings.find((l) => l.id === id);
  if (!listing) return {};
  return {
    title: `${listing.title} — ${listing.location} | Imobiliare Demo`,
    description: listing.description,
    openGraph: {
      title: `${listing.title} — ${listing.location}`,
      description: listing.description,
      images: [{ url: listing.image }],
    },
  };
}

export default async function PropertyPage({ params }: { params: Params }) {
  const { id } = await params;
  const listing = listings.find((l) => l.id === id);

  if (!listing) notFound();

  const waMessage = encodeURIComponent(
    `Përshëndetje! Jam i interesuar për pronën: ${listing.title} — ${listing.location} (${listing.price}). Mund të më jepni më shumë informacion?`
  );

  return (
    <div className="min-h-screen bg-[#0a0a0a] pt-20 pb-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back link */}
        <Link
          href="/prona"
          className="inline-flex items-center gap-2 text-gray-500 hover:text-[#c9a84c] text-sm transition-colors mb-8 mt-4"
        >
          <HiArrowLeft size={16} />
          Kthehu te pronat
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8 lg:gap-10">
          {/* Left: Image + details */}
          <div className="lg:col-span-3">
            {/* Main image */}
            <div className="relative h-[300px] sm:h-[400px] md:h-[480px] rounded-2xl overflow-hidden mb-5">
              <Image
                src={listing.image}
                alt={`${listing.title} - ${listing.location}`}
                fill
                className="object-cover"
                sizes="(max-width: 1024px) 100vw, 60vw"
                priority
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />

              {/* Badges */}
              <div className="absolute top-5 left-5 flex gap-2">
                <span
                  className={`text-xs font-bold px-3 py-1.5 rounded-full ${
                    listing.type === "Qira"
                      ? "bg-blue-500 text-white"
                      : "bg-[#c9a84c] text-black"
                  }`}
                >
                  {listing.type}
                </span>
                <span className="text-xs font-medium px-3 py-1.5 rounded-full bg-black/60 text-white backdrop-blur-sm">
                  {listing.city}
                </span>
              </div>

              {/* Price overlay */}
              <div className="absolute bottom-5 left-5">
                <div className="font-display text-2xl sm:text-3xl font-bold text-[#c9a84c]">
                  {listing.price}
                </div>
                {listing.isMonthly && (
                  <div className="text-gray-300 text-xs">/ muaj</div>
                )}
              </div>
            </div>

            {/* Title + location */}
            <div className="mb-6">
              <h1 className="font-display text-2xl sm:text-3xl md:text-4xl font-bold text-white mb-3">
                {listing.title}
              </h1>
              <div className="flex items-center gap-2 text-gray-400">
                <HiLocationMarker className="text-[#c9a84c]" size={16} />
                <span className="text-sm">{listing.location}</span>
              </div>
            </div>

            {/* Stats grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
              {[
                {
                  icon: MdSquareFoot,
                  label: "Sipërfaqe",
                  value: listing.area,
                },
                listing.bedrooms > 0 && {
                  icon: IoBed,
                  label: "Dhoma gjumi",
                  value: `${listing.bedrooms}`,
                },
                {
                  icon: HiHomeModern,
                  label: "Kati",
                  value: `${listing.floor}`,
                },
                {
                  icon: HiLocationMarker,
                  label: "Qyteti",
                  value: listing.city,
                },
              ]
                .filter(Boolean)
                .map((item) => {
                  if (!item) return null;
                  const Icon = item.icon;
                  return (
                    <div
                      key={item.label}
                      className="bg-[#111111] border border-[#1a1a1a] rounded-xl p-4 text-center"
                    >
                      <Icon
                        className="text-[#c9a84c] mx-auto mb-1.5"
                        size={20}
                      />
                      <div className="text-white font-semibold text-sm">
                        {item.value}
                      </div>
                      <div className="text-gray-500 text-xs">{item.label}</div>
                    </div>
                  );
                })}
            </div>

            {/* Description */}
            <div className="bg-[#111111] border border-[#1a1a1a] rounded-2xl p-6 mb-6">
              <h2 className="font-display text-lg font-semibold text-white mb-3">
                Përshkrim
              </h2>
              <p className="text-gray-400 text-sm leading-relaxed">
                {listing.description}
              </p>
            </div>

            {/* Features */}
            <div className="bg-[#111111] border border-[#1a1a1a] rounded-2xl p-6">
              <h2 className="font-display text-lg font-semibold text-white mb-4">
                Karakteristikat
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {listing.features.map((feature) => (
                  <div
                    key={feature}
                    className="flex items-center gap-2.5 text-gray-300 text-sm"
                  >
                    <HiCheckCircle className="text-[#c9a84c] shrink-0" size={16} />
                    {feature}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right: Sticky CTA */}
          <div className="lg:col-span-2">
            <div className="sticky top-24">
              {/* CTA Card */}
              <div className="bg-[#111111] border border-[#1a1a1a] rounded-2xl p-7 mb-5">
                <div className="font-display text-3xl font-bold text-[#c9a84c] mb-1">
                  {listing.price}
                </div>
                {listing.isMonthly && (
                  <div className="text-gray-500 text-xs mb-4">muaj / qira</div>
                )}

                <div className="h-px bg-[#1a1a1a] my-5" />

                <h3 className="font-semibold text-white mb-2 text-sm">
                  Jeni të interesuar?
                </h3>
                <p className="text-gray-500 text-xs leading-relaxed mb-5">
                  Kontaktoni agjentin tonë tani për informacion të plotë dhe
                  caktim vizite.
                </p>

                <a
                  href={`https://wa.me/355692081322?text=${waMessage}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2.5 w-full bg-[#c9a84c] text-black font-bold py-4 rounded-xl hover:bg-[#d4b86a] transition-all duration-300 hover:shadow-[0_0_25px_rgba(201,168,76,0.35)] text-sm tracking-wider mb-3"
                >
                  <FaWhatsapp size={18} />
                  Na kontaktoni — WhatsApp
                </a>

                <a
                  href="tel:+355692081322"
                  className="flex items-center justify-center gap-2 w-full border border-[#2a2a2a] text-gray-300 hover:text-[#c9a84c] hover:border-[#c9a84c]/40 font-medium py-3.5 rounded-xl transition-all duration-300 text-sm"
                >
                  +355 69 208 1322
                </a>
              </div>

              {/* Info box */}
              <div className="bg-[#111111] border border-[#1a1a1a] rounded-2xl p-5">
                <div className="text-xs text-gray-500 leading-relaxed">
                  <div className="flex items-center gap-2 text-[#c9a84c] font-semibold mb-2 text-sm">
                    <HiCheckCircle size={16} />
                    Garantuar nga Imobiliare Demo
                  </div>
                  Çdo pronë në platformën tonë është verifikuar dhe vlerësuar
                  nga agjentët tanë. Transparencë dhe siguri totale.
                </div>
              </div>

              {/* VELOX credit */}
              <p className="text-center text-gray-700 text-xs mt-5">
                Faqe e ndërtuar nga{" "}
                <a
                  href="https://velox-design.netlify.app"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[#c9a84c] hover:text-[#d4b86a] transition-colors"
                >
                  VELOX Studio
                </a>{" "}
                — Web Design Profesional në 7 Ditë
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

"use client";

import { motion } from "framer-motion";
import Image from "next/image";
import Link from "next/link";
import { HiLocationMarker } from "react-icons/hi";
import { IoBed } from "react-icons/io5";
import { MdSquareFoot } from "react-icons/md";
import { Listing } from "@/lib/listings";

interface PropertyCardProps {
  listing: Listing;
  index?: number;
}

export default function PropertyCard({ listing, index = 0 }: PropertyCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.5, delay: index * 0.08 }}
      className="group bg-[#111111] rounded-2xl overflow-hidden border border-[#1a1a1a] hover:border-[#c9a84c]/40 transition-all duration-500 flex flex-col"
    >
      {/* Image */}
      <div className="relative h-56 overflow-hidden shrink-0">
        <Image
          src={listing.image}
          alt={`${listing.title} - ${listing.location}`}
          fill
          className="object-cover transition-transform duration-700 group-hover:scale-110"
          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />

        {/* Type badge */}
        <span
          className={`absolute top-4 left-4 text-xs font-bold px-3 py-1 rounded-full ${
            listing.type === "Qira"
              ? "bg-blue-500 text-white"
              : "bg-[#c9a84c] text-black"
          }`}
        >
          {listing.type}
        </span>

        {/* Price */}
        <div className="absolute bottom-4 left-4">
          <span className="font-display font-bold text-xl text-[#c9a84c]">
            {listing.price}
          </span>
        </div>
      </div>

      {/* Body */}
      <div className="p-5 flex flex-col flex-1">
        <h3 className="font-display text-lg font-semibold text-white mb-1.5 group-hover:text-[#c9a84c] transition-colors duration-300">
          {listing.title}
        </h3>

        <div className="flex items-center gap-1.5 text-gray-500 text-sm mb-4">
          <HiLocationMarker className="text-[#c9a84c] shrink-0" size={14} />
          <span>{listing.location}</span>
        </div>

        {/* Stats row */}
        <div className="flex items-center gap-4 text-xs text-gray-500 pb-4 mb-4 border-b border-[#1a1a1a]">
          {listing.bedrooms > 0 && (
            <div className="flex items-center gap-1.5">
              <IoBed className="text-[#c9a84c]" size={14} />
              <span>{listing.bedrooms} dhoma</span>
            </div>
          )}
          <div className="flex items-center gap-1.5">
            <MdSquareFoot className="text-[#c9a84c]" size={15} />
            <span>{listing.area}</span>
          </div>
          <div className="ml-auto text-[10px] bg-[#1a1a1a] border border-[#2a2a2a] px-2 py-0.5 rounded text-gray-400">
            Kati {listing.floor}
          </div>
        </div>

        <Link
          href={`/prona/${listing.id}`}
          className="mt-auto block text-center py-2.5 rounded-xl border border-[#c9a84c]/30 text-[#c9a84c] text-sm font-semibold hover:bg-[#c9a84c] hover:text-black hover:border-[#c9a84c] transition-all duration-300"
        >
          Shiko Detajet
        </Link>
      </div>
    </motion.div>
  );
}

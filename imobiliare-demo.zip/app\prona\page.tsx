"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { listings, Listing } from "@/lib/listings";
import PropertyCard from "@/components/PropertyCard";
import SearchFilter from "@/components/SearchFilter";
import { ListingsGridSkeleton } from "@/components/LoadingSkeleton";

export default function PronaPage() {
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [city, setCity] = useState("Të gjitha");
  const [type, setType] = useState("Të gjitha");

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 900);
    return () => clearTimeout(t);
  }, []);

  const filtered: Listing[] = listings.filter((l) => {
    const matchSearch =
      search === "" ||
      l.title.toLowerCase().includes(search.toLowerCase()) ||
      l.location.toLowerCase().includes(search.toLowerCase());
    const matchCity = city === "Të gjitha" || l.city === city;
    const matchType = type === "Të gjitha" || l.type === type;
    return matchSearch && matchCity && matchType;
  });

  return (
    <div className="min-h-screen bg-[#0a0a0a] pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Page header */}
        <motion.div
          className="mb-10"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex items-center gap-3 mb-3">
            <div className="h-px w-8 bg-[#c9a84c]" />
            <span className="text-[#c9a84c] text-xs tracking-[0.35em] uppercase font-medium">
              Koleksioni ynë
            </span>
          </div>
          <h1 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-3">
            Të Gjitha Pronat
          </h1>
          <p className="text-gray-400 text-sm sm:text-base max-w-xl">
            Zgjidhni nga lista jonë e pronave të zgjedhura me kujdes në qytetet
            kryesore të Shqipërisë.
          </p>
        </motion.div>

        {/* Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <SearchFilter
            search={search}
            city={city}
            type={type}
            onSearch={setSearch}
            onCity={setCity}
            onType={setType}
            resultCount={filtered.length}
          />
        </motion.div>

        {/* Content */}
        {loading ? (
          <ListingsGridSkeleton />
        ) : (
          <AnimatePresence mode="wait">
            {filtered.length > 0 ? (
              <motion.div
                key="results"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
              >
                {filtered.map((listing, i) => (
                  <PropertyCard key={listing.id} listing={listing} index={i} />
                ))}
              </motion.div>
            ) : (
              <motion.div
                key="empty"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="text-center py-24"
              >
                <div className="text-5xl mb-4">🏠</div>
                <h3 className="font-display text-xl text-white mb-2">
                  Nuk u gjet asnjë pronë
                </h3>
                <p className="text-gray-500 text-sm">
                  Provoni të ndryshoni filtrat ose kërkimin.
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        )}
      </div>
    </div>
  );
}

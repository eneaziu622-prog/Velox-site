import type { Metadata } from "next";
import Hero from "@/components/Hero";
import FeaturedListings from "@/components/FeaturedListings";
import WhyChooseUs from "@/components/WhyChooseUs";
import Testimonials from "@/components/Testimonials";

export const metadata: Metadata = {
  title: "Imobiliare Demo | Prona të Zgjedhura në Shqipëri",
  description:
    "Gjeni pronën tuaj të ëndrrave. Shërbim profesional imobiliar me mbi 500 klientë të kënaqur në Tiranë, Durrës, Vlorë dhe Sarandë.",
};

export default function HomePage() {
  return (
    <>
      <Hero />
      <FeaturedListings />
      <WhyChooseUs />
      <Testimonials />

      {/* Final CTA strip */}
      <section className="py-20 bg-[#111111] border-y border-[#1a1a1a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
          <p className="text-[#c9a84c] text-xs tracking-[0.35em] uppercase font-medium mb-4">
            Gati të filloni?
          </p>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-5">
            Na Kontaktoni Sot
          </h2>
          <p className="text-gray-400 mb-8 max-w-lg mx-auto text-sm sm:text-base">
            Ekipi ynë është gati t&apos;ju ndihmojë të gjeni pronën perfekte.
            Kontaktoni tani për konsulencë falas.
          </p>
          <a
            href="https://wa.me/355692081322"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 bg-[#c9a84c] text-black font-bold px-10 py-4 rounded-full hover:bg-[#d4b86a] transition-all duration-300 hover:shadow-[0_0_35px_rgba(201,168,76,0.4)] hover:scale-105 text-sm tracking-wider"
          >
            Na kontaktoni tani — falas
          </a>
          <p className="text-gray-600 text-xs mt-6">
            Faqe e ndërtuar nga VELOX Studio — Web Design Profesional në 7 Ditë
          </p>
        </div>
      </section>
    </>
  );
}

"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { FaWhatsapp } from "react-icons/fa";
import { HiArrowRight } from "react-icons/hi";

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1486325212027-8081e485255e?w=1920&q=80&fit=crop')",
        }}
      />
      {/* Overlays */}
      <div className="absolute inset-0 bg-[#0a0a0a]/65" />
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0a]/40 via-transparent to-[#0a0a0a]" />

      {/* Content */}
      <div className="relative z-10 text-center px-4 sm:px-6 max-w-5xl mx-auto pt-20">
        {/* Eyebrow */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="flex items-center justify-center gap-3 mb-6"
        >
          <div className="h-px w-12 bg-[#c9a84c]" />
          <span className="text-[#c9a84c] text-xs sm:text-sm tracking-[0.35em] uppercase font-medium">
            Agjenci Imobiliare
          </span>
          <div className="h-px w-12 bg-[#c9a84c]" />
        </motion.div>

        {/* Headline */}
        <motion.h1
          className="font-display font-bold leading-[1.1] mb-6"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          <span className="block text-4xl sm:text-5xl md:text-6xl lg:text-7xl text-white">
            Gjeni Pronën Tuaj
          </span>
          <span className="block text-4xl sm:text-5xl md:text-6xl lg:text-7xl text-[#c9a84c] gold-shimmer">
            të Ëndrrave
          </span>
        </motion.h1>

        {/* Subtext */}
        <motion.p
          className="text-gray-300 text-base sm:text-lg md:text-xl max-w-xl mx-auto mb-10 leading-relaxed"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          Shërbim profesional imobiliar në të gjithë Shqipërinë
        </motion.p>

        {/* CTAs */}
        <motion.div
          className="flex flex-col sm:flex-row gap-4 justify-center"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
        >
          <Link
            href="/prona"
            className="inline-flex items-center justify-center gap-2 bg-[#c9a84c] text-black font-bold px-8 py-4 rounded-full hover:bg-[#d4b86a] transition-all duration-300 hover:shadow-[0_0_35px_rgba(201,168,76,0.45)] hover:scale-105 text-sm tracking-wider"
          >
            Shiko Pronat
            <HiArrowRight size={18} />
          </Link>
          <a
            href="https://wa.me/355692081322"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 border-2 border-[#c9a84c] text-[#c9a84c] font-bold px-8 py-4 rounded-full hover:bg-[#c9a84c] hover:text-black transition-all duration-300 hover:scale-105 text-sm tracking-wider"
          >
            <FaWhatsapp size={18} />
            WhatsApp
          </a>
        </motion.div>

        {/* Stats */}
        <motion.div
          className="flex flex-wrap items-center justify-center gap-8 mt-16"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 1.1 }}
        >
          {[
            { value: "500+", label: "Klientë të kënaqur" },
            { value: "200+", label: "Prona të shitura" },
            { value: "10+", label: "Vite eksperiencë" },
          ].map(({ value, label }) => (
            <div key={label} className="text-center">
              <div className="font-display text-2xl font-bold text-[#c9a84c]">
                {value}
              </div>
              <div className="text-gray-400 text-xs tracking-wider mt-0.5">
                {label}
              </div>
            </div>
          ))}
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
        animate={{ y: [0, 8, 0] }}
        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
      >
        <div className="w-6 h-10 border-2 border-[#c9a84c]/40 rounded-full flex justify-center pt-2">
          <motion.div
            className="w-1 h-2.5 bg-[#c9a84c]/60 rounded-full"
            animate={{ opacity: [1, 0.3, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        </div>
      </motion.div>
    </section>
  );
}

export function PropertyCardSkeleton() {
  return (
    <div className="bg-[#111111] rounded-2xl overflow-hidden border border-[#1a1a1a]">
      <div className="h-56 bg-[#1a1a1a] skeleton" />
      <div className="p-5">
        <div className="h-5 bg-[#1a1a1a] skeleton rounded-lg mb-2 w-3/4" />
        <div className="h-4 bg-[#1a1a1a] skeleton rounded-lg mb-4 w-1/2" />
        <div className="flex gap-4 pb-4 mb-4 border-b border-[#222]">
          <div className="h-3 bg-[#1a1a1a] skeleton rounded-lg w-20" />
          <div className="h-3 bg-[#1a1a1a] skeleton rounded-lg w-16" />
        </div>
        <div className="h-10 bg-[#1a1a1a] skeleton rounded-xl" />
      </div>
    </div>
  );
}

export function ListingsGridSkeleton() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {Array.from({ length: 6 }).map((_, i) => (
        <PropertyCardSkeleton key={i} />
      ))}
    </div>
  );
}
